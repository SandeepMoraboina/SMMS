<?php require 'headerDB.php';
?>
<?php

$name = $_POST['hidden_name'];

if(isset($_POST['update'])){
	$Update = "UPDATE vendors SET V_Name='$_POST[name]', Phone=$_POST[phone], Email='$_POST[email]', Address='$_POST[address]' WHERE v_id=$_POST[hiddenVal]";
	mysql_query($Update, $con);
	header('Location: vendor_list.php');
}




$id = "SELECT * FROM vendors WHERE v_name = '$name' ";
$mydata = mysql_query($id, $con);

while($vfetch = mysql_fetch_array($mydata)){
		echo "<div class='container'>
			<div class='row'>
				<div style='width: 40%; margin: 30px auto;'>
					<h1 style='text-align: center;'>Update Supplier " . $_POST['hidden_name'] . "</h1>
					<form action='vendor_update.php' method='POST'>
						<div class='form-group'>
						    <label for='ven_name'>Name</label>
						    <input type='text' name='name' class='form-control' id='ven_name' placeholder='Enter vendor name' value=" .$vfetch['v_name'] . ">
						</div>
						<div class='form-group'>
						    <label for='ven_mob'>Mobile Number</label>
						    <input type='number' name='phone' class='form-control' id='ven_mob' placeholder='Enter vendor mobile number' value=" .$vfetch['phone'] . ">
						</div>
						<div class='form-group'>
						    <label for='ven_email'>Email_id</label>
						    <input type='email' name='email' class='form-control' id='ven_email' aria-describedby='emailHelp' placeholder='Enter vendor email' value=" .$vfetch['email'] . ">
						</div>
						<div class='form-group'>
						    <label for='ven_address'>Address</label>
						    <textarea class='form-control' name='address' id='ven_address' rows='3' placeholder='Enter vendor address'>" . $vfetch['address'] ."</textarea>
						</div>
						<div>
						  	<a href='vendor_list.php'>View all the items</a>		
						</div>
						<div>
						  	<input style='margin-top: 10px' type=submit name=update value=Update class='btn btn-success btn-block'>
						</div>
						<input type=hidden name=hiddenVal value=" .$vfetch['v_id'] . ">
					</form>

				</div>
			</div>
		</div>
		";

	// echo "<form action='vendor_update.php' method='POST'>
	// 	Name :<input type=text name=name value=" .$vfetch['v_name'] . "> <br /> 
	// 	Phone No.:<input type=number name=phone value=" .$vfetch['phone'] . "> <br />
	// 	Email-ID:<input type=email name=email value=" .$vfetch['email'] . ">  <br />
	// 	Address:<textarea w32api_deftype(typename, member1_type, member1_name) name=address>" . $vfetch['address'] ."</textarea> <br />	 
	// 	<input type=hidden name=hiddenVal value=" .$vfetch['v_id'] . ">  <br />
	// 	<input type=submit name=update value=Update>  	
	// 	</form>";
	break;
}


 ?>
<?php require 'footer.php';
?>