<?php require 'headerDB.php';
?>
<?php
$name = $_POST['hidden_name'];

if(isset($_POST['update'])){
	$Update = "UPDATE employees SET E_Name='$_POST[name]', E_Age=$_POST[age], E_Phone=$_POST[phone], E_Email='$_POST[email]', E_Address='$_POST[address]', E_Section=$_POST[section] WHERE E_id=$_POST[hiddenVal]";
	mysql_query($Update, $con);
	header('Location: employee_list.php');
}

	
$id = "SELECT * FROM employees WHERE e_name = '$name' ";
$mydata = mysql_query($id, $con);

while($vfetch = mysql_fetch_array($mydata)){
	echo "string <div class='container add_cont'>
	<div class='row'>
		<div style='width: 35%; margin: 30px auto;'>
				<form action='employee_update.php' method='POST'>
				<h1 style='text-align: center;'>Update Employee " . $_POST['hidden_name']. "</h1>
			  <div class='form-group'>
			    <label for='emp_name'>Name</label>
			    <input type='text' name='name' class='form-control' id='emp_name' placeholder='Enter employee name' value=" .$vfetch['e_name'] . ">
			  </div>
			  <div class='form-group'>
			    <label for='emp_age'>Age</label>
			    <input type='number' name='age' min='20' class='form-control' id='emp_age' placeholder='Enter employee age'value=".$vfetch['e_age'] .">
			  </div>
			  <div class='form-group'>
			    <label for='emp_phone'>Mobile Number</label>
			    <input type='number' name='phone' min='0' class='form-control' id='emp_phone' placeholder=' Enter employee mobile number' value=" .$vfetch['e_phone'] . ">
			  </div>
			  <div class='form-group'>
			    <label for='emp_email'>Email_id</label>
			    <input type='email' name='email' class='form-control' id='emp_email' aria-describedby='emailHelp' placeholder='Enter employee email' value=" .$vfetch['e_email'] . ">
			  </div>
			  <div class='form-group'>
			    <label for='emp_address'>Address</label>
			    <textarea class='form-control' name='address' id='emp_address' rows='3' placeholder='Enter employee address'>" .$vfetch['e_address']. "</textarea>
			  </div>
			  <div class='form-group'>
			    <label for='emp_sec'>Section_id</label>
			    <input type='number' name='section' class='form-control' id='emp_sec' min='1' placeholder='Enter employee section'value=".$vfetch['e_section'] .">
			  </div>
			  <div>
			  	<a href='employee_list.php'>View all the Employees</a>		
			  </div>
			  <div>
			  	<input style='margin-top: 10px' class='btn btn-success btn-block' type=submit name=update value=Update> 
				  </div>
				  	<input type=hidden name=hiddenVal value=" .$vfetch['e_id'] . ">  <br /> 
				</form>
			</div>
		</div>
	</div>";
	break;
}


 ?>
<?php require 'footer.php';
?>