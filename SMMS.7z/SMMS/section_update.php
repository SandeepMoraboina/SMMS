<?php require 'headerDB.php';
?>
<?php

$name = $_POST['hidden_name'];

if(isset($_POST['update'])){
	$Update = "UPDATE sections SET S_Name='$_POST[name]', Description='$_POST[description]' WHERE s_id=$_POST[hiddenVal]";
	mysql_query($Update, $con);
	header('Location: section_list.php');
}




$id = "SELECT * FROM sections WHERE s_name = '$name' ";
$mydata = mysql_query($id, $con);
while($vfetch = mysql_fetch_array($mydata)){
	echo "<div class='container'>
	<div class='row'>
		<div style='width: 40%; margin: 30px auto;'>
			<h1 style='text-align: center;'>Update Section " . $_POST['hidden_name'] . "</h1>
			<form action='section_update.php' method='POST'>
				<div class='form-group'>
				    <label for='sec_name'>Name</label>
				    <input type='text' name='name' class='form-control' id='sec_name' placeholder='Enter section name' value=" .$vfetch['s_name'] . ">
			  	</div>
			  	<div class='form-group'>
				    <label for='sec_desc'>Description</label>
				    <textarea class='form-control' name='description' id='sec_desc' rows='3' placeholder='Enter section description'>" . $vfetch['description'] ."</textarea>
				</div>
				<div>
				  	<a href='section_list.php'>View all the Sections</a>		
			 	</div>
			  	<div>
			  		<input style='margin-top: 10px;' type=submit name=update value=Update class='btn btn-success btn-block'>
			  	</div>
			  	<input type=hidden name=hiddenVal value=" .$vfetch['s_id'] . ">
			</form>
		</div>
	</div>
</div>";

	break;
}


 ?>
<?php require 'footer.php';
?>