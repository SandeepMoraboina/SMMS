<!DOCTYPE html>
<html>
<head>
	<title>Sql Connect</title>
</head>
<body>

<?php 
$con = mysql_connect("localhost","SMMS","smms");
if(!$con){
	die("Cannot Connect".mysql_error());
}

mysql_select_db("supermarket",$con);

$sql = "CREATE TABLE sections (
		s_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
		s_name VARCHAR(30) NOT NULL UNIQUE,
		description VARCHAR(100) NOT NULL
		)";

if(mysql_query($sql, $con)){
	echo "Table Successfully created";
}else{
	echo "Error" . mysql_error();
}

mysql_close($con);
?>

</body>
</html>