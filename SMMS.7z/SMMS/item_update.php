<?php require 'headerDB.php';
?>
<?php

$hid = $_POST['hidden_id'];

if(isset($_POST['update'])){
	$Update = "UPDATE items SET Name='$_POST[name]', Price=$_POST[price], Remarks='$_POST[remarks]', Vendor_id=$_POST[vendor], Section_id=$_POST[section] WHERE id=$_POST[hiddenVal]";
	mysql_query($Update, $con);
	header('Location: item_list.php');
}



$id = "SELECT * FROM items WHERE id = '$hid' ";
$mydata = mysql_query($id, $con);

while($ifetch = mysql_fetch_array($mydata)){
	echo "
					<div class='container'>
			<div class='row'>
				<div style='width: 35%; margin: 30px auto;'>
					<h1 style='text-align: center;'>Update Item " . $_POST['hidden_name'] . "</h1>
						<form action='item_update.php' method='POST'>
							<div class='form-group'>
							    <label for='item_name'>Name</label>
							    <input type='text' name='name' class='form-control' id='item_name' placeholder='Enter item name' value =" .$ifetch['name'] . ">
							</div>	
							<div class='form-group'>
							    <label for='item_price'>Price</label>
							    <input type='number' name='price' class='form-control' min='1' id='item_price' placeholder='Enter item price' value =" .$ifetch['price'] . ">
							</div>
							<div class='form-group'>
							    <label for='item_rem'>Remarks</label>
							    <input type='text' name='remarks' class='form-control' id='item_rem' placeholder='Enter item remarks' value =" .$ifetch['remarks'] . ">
							</div>
							<div class='form-group'>
							    <label for='item_ven_id'>Vendor_id</label>
							    <input type='number' name='vendor' class='form-control' min='1' id='item_ven_id' placeholder='Enter item vendor id' value =" .$ifetch['vendor_id'] . ">
							</div>
							<div class='form-group'>
							    <label for='item_sec_id'>Section_id</label>
							    <input type='number' name='section' class='form-control' min='1' id='item_sec_id' placeholder='Enter item section id' value =" .$ifetch['section_id'] . ">
							</div>
							<div>
						  		<a href='item_list.php'>View all the items</a>
						  	</div>
							<div>
							  	<input style='margin-top: 10px' type=submit name=update value=Update class='btn btn-success btn-block'>
							</div>
							<input type=hidden name=hiddenVal value=" .$ifetch['id'] . "> 
						</form>
				</div>
			</div>
		</div>

		";
	break;
}


 ?>
<?php require 'footer.php';
?>