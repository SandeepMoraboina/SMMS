<?php require 'headerDB.php';
?>
<div class="container ccenter">
	<div class="jumbotron">
		<h1>All the Supermarket Suppliers</h1>
		<a class="btn btn-primary btn-lg btn-list" href="add_vendor.php">Add new Vendor</a>
	</div>
	
<?php
$sql = "SELECT * FROM vendors";
$myData = mysql_query($sql, $con);

if(mysql_affected_rows() != 0){
	echo "<div class='container'>
	<table class='tabven' border=1>
	<tr>
		<th>Vendor-ID</th>
		<th>Name</th>
		<th>Phone No.</th>
		<th>Email-ID</th>
		<th>Show</th>
	</tr>";

while($require = mysql_fetch_array($myData)){
	echo "<form action = 'vendors_show.php' method='POST'>";
	echo "<tr>";
	echo "<td>" . "<input class='ilist' type=number name=id readonly value=" .$require['v_id'] .">" . "</td>"; 	
	echo "<td>" . "<input class='ilist' type=text name=name readonly value=" .$require['v_name'] .">" . "</td>"; 
	echo "<td>" . "<input class='ilist' type=number name=phone readonly value=" .$require['phone'] .">" . "</td>"; 
	echo "<td>" . "<input class='ilist' type=text name=email readonly value=" .$require['email'] .">" . "</td>";  
	echo "<td>" . "<input class='btn btn-success btn-show' type=submit name=show value= Show>" . "</td>"; 
	echo "<td>" . "<textarea class='ilist' style='display: none;' readonly name=address>" .$require['address'] ."</textarea>" . "</td>";  
	echo "</tr>";
	echo "</form>";
}

echo "</table>
		</div>";
}else{
	echo "<div class='alert alert-danger'>
			  <strong>Note!</strong> No Vendors to display.
			</div>";
}


mysql_close($con);

?>

<?php require 'footer.php';
?>	
</div>
