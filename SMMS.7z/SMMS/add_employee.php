	<?php require 'header.php';
?>
<div class="container add_cont">
	<div class="row">
		<div style="width: 40%; margin: 30px auto;">
				<form action="add_employee.php" method="POST">
				<h1 style="text-align: center;">Add New Employee</h1>
			  <div class="form-group">
			    <label for="emp_name">Name</label>
			    <input type="text" name="name" class="form-control" id="emp_name" placeholder="Enter employee name">
			  </div>
			  <div class="form-group">
			    <label for="emp_age">Age</label>
			    <input type="number" name="age" min="20" class="form-control" id="emp_age" placeholder="Enter employee age">
			  </div>
			  <div class="form-group">
			    <label for="emp_phone">Mobile Number</label>
			    <input type="number" name="phone" min="0" class="form-control" id="emp_phone" placeholder=" Enter employee mobile number">
			  </div>
			  <div class="form-group">
			    <label for="emp_email">Email_id</label>
			    <input type="email" name="email" class="form-control" id="emp_email" aria-describedby="emailHelp" placeholder="Enter employee email">
			  </div>
			  <div class="form-group">
			    <label for="emp_address">Address</label>
			    <textarea class="form-control" name="address" id="emp_address" rows="3" placeholder="Enter employee address"></textarea>
			  </div>
			  <div class="form-group">
			    <label for="emp_sec">Section_id</label>
			    <input type="number" name="section" class="form-control" id="emp_sec" min="1" placeholder="Enter employee section">
			  </div>
			  <div>
			  	<a href="employee_list.php">View all the Employees</a>		
			  </div>
			  <div>
			  	<input style="margin-top: 10px" type="submit" name="submit" class="btn btn-success btn-block">
			  </div>
			</form>
		</div>
	</div>
</div>

<?php 

if(isset($_POST['submit'])){

$con = mysql_connect("localhost","SMMS","smms");
if(!$con){
	die("Cannot Connect" . mysql_error());
}

mysql_select_db("supermarket",$con);

$sql = "INSERT INTO employees (E_Name,E_Age,E_Phone,E_Email,E_Address,E_Section) values('$_POST[name]', $_POST[age], $_POST[phone], '$_POST[email]', '$_POST[address]', $_POST[section])";

if(mysql_query($sql, $con)){
	echo "Succes!";
	header('Location: employee_list.php');
}else{
	echo "Error:" . mysql_error();
}

mysql_close($con);
}

?>

<?php require 'footer.php';
?>