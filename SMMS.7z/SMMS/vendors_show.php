<?php require 'headerDB.php';
?>
<div class="container">
	<div class="row">
		<?php
		if(isset($_POST['delete'])){
			$Delete = "DELETE FROM items WHERE id='$_POST[hidden]'";
			mysql_query($Delete, $con);
			header('Location: vendor_list.php');
		}

		$value =null;
		$name = $_POST['name'];

		echo "<div  style='width: 1000px; height:300px; margin: 30px auto;' class='jumbotron' id='jumbo-show'>
		<h1>" . $_POST['name'] . "'s Items" . "</h1> 
		<h4> Contact: " . $_POST['phone'] . "</h4> 
		<h4> Email-Id: " . $_POST['email'] . "</h4> 
		<h4> Address: " . $_POST['address'] . "</h4>
		</div>"; 

		
		$id = "SELECT * FROM vendors WHERE v_name = '$name' ";
		$mydata = mysql_query($id, $con);

		while($vfetch = mysql_fetch_array($mydata)){
			$value = $vfetch['v_id'];
			break;
		}

		$ItemSelect = "SELECT * FROM items WHERE vendor_id = '$value' ";
		$selected = mysql_query($ItemSelect, $con);

		if(isset($_POST['deleteVendor'])){
			$DelVen = "DELETE FROM vendors WHERE v_id='$_POST[hidden_id]'";
			if(mysql_query($DelVen, $con)){
				header('Location: vendor_list.php');
			} else{
				echo "Error:" . mysql_error();
			}
		}	

		echo "<a class='btn btn-primary btn-lg' style='float: left; margin-left: 85px;' href='add_item.php'>Add Items</a>
			  <form action= 'vendor_update.php' method= 'POST' >" .
				"<input type=hidden name=hidden_name value=" .$vfetch['v_name'] .">" .
				"<input class='btn btn-warning btn-lg' style='float: right; margin-right: 85px;' type=submit name=updateVendor value=Update>" .
			"</form>
			 <form action= 'vendors_show.php' method= 'POST' >" .
				"<input type=hidden name=hidden_id value=" .$vfetch['v_id'] .">" .
				"<input class='btn btn-danger btn-lg' style='float: right; margin-right: 360px;' type=submit name=deleteVendor value=Delete>" .
			"</form> <br /> <br /> <br />";

		if(mysql_affected_rows() != 0){
			echo "<div class='ccenter container'>
			<h3>Items under this vendor</h3>
			<table border=1 style='margin-left:225px;'>
			<tr>
				<th>Name</th>
				<th>Price</th>
				<th>Remarks</th>
				<th>Update</th>
				<th></th>
				<th></th>
				<th>Delete</th>
			</tr>";

		while($require = mysql_fetch_array($selected)){
			echo "<form action = 'item_update.php' method='POST'>";
			echo "<tr>";
			echo "<td>" . "<input class='ilist' type=text name=name readonly  value=" .$require['name'] .">" . "</td>"; 
			echo "<td>" . "<input class='ilist' type=number name=price readonly value=" .$require['price'] .">" . "</td>"; 
			echo "<td>" . "<input class='ilist' type=text name=remarks readonly value=" .$require['remarks'] .">" . "</td>"; 
			echo "<td>" . "<input type=submit class='btn btn-warning' style='margin:5px;' name=updateItem readonly value=Update>" . "</td>";
			echo "<td>" . "<input type=hidden name=hidden_id readonly value=" .$require['id'] .">" . "</td>";   
			echo "<td>" . "<input type=hidden name=hidden_name readonly  value=" .$require['name'] .">" . "</td>";  
			echo "</form>";
			echo "<form action = 'vendors_show.php' method='POST'>"; 
			echo "<td>" . "<input type=submit name=delete class='btn btn-danger' style='margin:5px;' readonly value=Delete>" . "</td>";
			echo "<td>" . "<input type=hidden name=hidden readonly value=" .$require['id'] .">" . "</td>";  
			echo "</form>";
			echo "</tr>"; 
		}

		echo "</table>
			</div>";
		}else{
				echo "<div style='width: 1000px; margin: 30px auto;' class='alert alert-danger' >
					  <strong>Note!</strong> This vendor has no items.
					</div>";
		}



		mysql_close($con);
		?>
	</div>
</div>


<?php require 'footer.php';
?>