<?php require 'headerDB.php';
?>
<div class="container">
	<div class="row">
		<div style="width: 40%; margin: 30px auto;">
			 
		</div>
				<?php

		if(isset($_POST['deleteEmp'])){
			$DelEmp = "DELETE FROM employees WHERE e_id='$_POST[hidden_del_id]'";
			if(mysql_query($DelEmp, $con)){
				header('Location: employee_list.php');
			} else{
				echo "Error:" . mysql_error();
			}
		}	

		$value =null;
		$name = $_POST['name'];

		echo "<div  style='width: 1200px; height:350px; margin: 30px auto;' class='jumbotron' id='jumbo-show'>
		<h1> Employee Name: " . $_POST['name'] . "</h1> 
		<h4> Contact: " . $_POST['phone'] . "</h4> 
		<h4> Age: " . $_POST['age'] . "</h4> 
		<h4> Email-Id: " . $_POST['email'] . "</h4> 
		<h4> Address: " . $_POST['address'] . "</h4> 
		<h4> Works in: Section " . $_POST['section'] . "</h4>
		</div>"; 

		echo "<form action= 'employee_update.php' method= 'POST' >" .
				"<input type=hidden name=hidden_name value=" .$_POST['name'] .">" .
				"<input type=submit class='btn btn-warning btn-lg' name=updateEmp style='float: left; margin-left: 250px;' value=Update>" .
			"</form>";

		echo "<form action= 'employee_show.php' method= 'POST' >" .
				"<input type=hidden name=hidden_del_id value=" .$_POST['id'] .">" .
				"<input type=submit name=deleteEmp class='btn btn-danger btn-lg' style='float: right; margin-right: 250px;' value=Delete>" .
			"</form> <br />";

		mysql_close($con);
		?>

	</div>
</div>

<?php require 'footer.php';
?>