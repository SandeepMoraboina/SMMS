<!DOCTYPE html>
<html>
<head>
	<title>Opps!</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
	<div style="margin-top: 20px;" class='container alert alert-danger'>
	  <strong>Opps!</strong> This page is under construction.
	</div>
<script type="text/javascript" src="jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>