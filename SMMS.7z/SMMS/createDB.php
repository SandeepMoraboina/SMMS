<!DOCTYPE html>
<html>
<head>
	<title>Sql Connect</title>
</head>
<body>

<?php 
$servername = "localhost";
$username = "SMMS";
$password = "smms";

$con = mysql_connect("localhost","SMMS","smms");
if(!$con){
	die("Cannot Connect".mysql_error());
}
$sql="CREATE DATABASE supermarket";
if(mysql_query("CREATE DATABASE supermarket",$con)){
	echo "Successfully created DB";
}else{
	echo "Error".mysql_error();
}

mysql_close($con);
?>

</body>
</html>