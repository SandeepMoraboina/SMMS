<?php require 'headerDB.php';
?>
<div class="container ccenter">
	<div class="jumbotron">
		<h1>Employees in the Supermarket</h1>
		<a class="btn btn-primary btn-lg btn-list" href="add_employee.php">Add New Employee</a>
	</div>

<?php

$sql = "SELECT * FROM employees";
$myData = mysql_query($sql, $con);

if(mysql_affected_rows() != 0){
	echo "<div class='container'>
	<table border=1>
	<tr>
		<th>Employee-ID</th>
		<th>Name</th>
		<th>Age</th>
		<th>Phone No.</th>
		<th>Email-ID</th>
		<th>Section</th>
		<th>Show</th>
	</tr>";

while($require = mysql_fetch_array($myData)){
	echo "<form action = 'employee_show.php' method='POST'>";
	echo "<tr>";
	echo "<td>" . "<input class='ilist' type=number name=id readonly value=" .$require['e_id'] .">" . "</td>"; 
	echo "<td>" . "<input class='ilist' type=text name=name readonly value=" .$require['e_name'] .">" . "</td>";
	echo "<td>" . "<input class='ilist' type=number name=age readonly value=" .$require['e_age'] .">" . "</td>"; 
	echo "<td>" . "<input class='ilist' type=number name=phone readonly value=" .$require['e_phone'] .">" . "</td>"; 
	echo "<td>" . "<input class='ilist' type=text name=email readonly value=" .$require['e_email'] .">" . "</td>";
	echo "<td>" . "<input class='ilist' type=number name=section readonly value=" .$require['e_section'] .">" . "</td>";  
	echo "<td>" . "<input type=submit name=show value=Show class='btn btn-success btn-show'>" . "</td>"; 
	echo "<td>" . "<textarea style='display: none;' readonly name=address>" .$require['e_address'] ."</textarea>" . "</td>";  
	echo "</tr>";
	echo "</form>";
}

echo "</table>
		</div>";
}else{
	echo "<div class='alert alert-danger'>
			  <strong>Note!</strong> No employee to display.
			</div>";
}


mysql_close($con);

?>
<?php require 'footer.php';
?>