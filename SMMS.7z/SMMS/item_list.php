<?php require 'headerDB.php';
?>
<div class="container ccenter">
	<div class="jumbotron">
		<h1>All the items in the Supermarket</h1>
		<a class="btn btn-primary btn-lg btn-list" href="add_item.php">Add new item</a> 
	</div>
	
<?php
$sql = "SELECT * FROM items";
$myData = mysql_query($sql,$con);

if(mysql_affected_rows() != 0){

echo "<div class='ccenter container'>
	<table style='text-align:center;' border=1>

	<tr>
		<th>Procuct-ID</th>
		<th>Name</th>
		<th>Price</th>
		<th>Remarks</th>
		<th>Vendor ID</th>
		<th>Section ID</th>
		<th>Show</th>
	</tr>";

while($require = mysql_fetch_array($myData)){
	echo "<form action = 'item_show.php' method='POST'>";
	echo "<tr>";
	echo "<td>" . "<input class='ilist' type=number readonly name=id value=" .$require['id'] .">" . "</td>";
	echo "<td>" . "<input class='ilist' type=text readonly name=name value=" .$require['name'] .">" . "</td>"; 
	echo "<td>" . "<input class='ilist' type=number readonly name=price value=" .$require['price'] .">" . "</td>"; 
	echo "<td>" . "<input class='ilist' type=text readonly name=remarks value=" .$require['remarks'] .">" . "</td>";  
	echo "<td>" . "<input class='ilist' type=number readonly name=vendor value=" .$require['vendor_id'] .">" . "</td>";
	echo "<td>" . "<input class='ilist' type=number readonly name=section value=" .$require['section_id'] .">" . "</td>"; 
	echo "<td>" . "<input class='btn btn-success btn-show' type=submit readonly name=show value= Show>" . "</td>"; 
	echo "</tr>";
	echo "</form>";
}
echo "</table>
		</div>";
}else{
		echo "<div class='alert alert-danger'>
			  <strong>Note!</strong> No Items to display.
			</div>";
}

mysql_close($con);

?>

<?php require 'footer.php';
?>
</div>
