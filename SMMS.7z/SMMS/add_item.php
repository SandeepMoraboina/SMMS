<?php require 'header.php';
?>
<div class="container">
	<div class="row">
		<div style="width: 40%; margin: 30px auto;">
			<h1 style="text-align: center;">Add a new Item</h1>
				<form action="add_item.php" method="POST">
					<div class="form-group">
					    <label for="item_name">Name</label>
					    <input type="text" name="name" class="form-control" id="item_name" placeholder="Enter item name">
					</div>
					<div class="form-group">
					    <label for="item_price">Price</label>
					    <input type="number" name="price" class="form-control" min="1" id="item_price" placeholder="Enter item price">
					</div>
					<div class="form-group">
					    <label for="item_rem">Remarks</label>
					    <input type="text" name="remarks" class="form-control" id="item_rem" placeholder="Enter item remarks">
					</div>
					<div class="form-group">
					    <label for="item_ven_id">Vendor_id</label>
					    <input type="number" name="vendor" class="form-control" min="1" id="item_ven_id" placeholder="Enter item vendor id">
					</div>
					<div class="form-group">
					    <label for="item_sec_id">Section_id</label>
					    <input type="number" name="section" class="form-control" min="1" id="item_sec_id" placeholder="Enter item section id">
					</div>
					<div>
				  		<a href="item_list.php">View all the items</a>
				  	</div>
					<div>
					  	<input style="margin-top: 10px" type="submit" name="submit" class="btn btn-success btn-block">
					</div>
				</form>
		</div>
	</div>
</div>

<?php 

if(isset($_POST['submit'])){

$con = mysql_connect("localhost","SMMS","smms");
if(!$con){
	die("Cannot Connect".mysql_error());
}

mysql_select_db("supermarket",$con);

$sql = "INSERT INTO items (Name,Price,Remarks,Vendor_id, Section_id) values('$_POST[name]', $_POST[price], '$_POST[remarks]', $_POST[vendor], $_POST[section])";

if(mysql_query($sql, $con)){
	header("Location: item_list.php");
}else{
	echo "Error:" . mysql_error();
}

mysql_close($con);
}

?>

<?php require 'footer.php';
?>