<?php require 'header.php';
?>

<div class="container">
	<div class="row">
		<div style="width: 40%; margin: 30px auto;">
			<h1 style="text-align: center;">Add a new vendor</h1>
			<form action="add_vendor.php" method="POST">
				<div class="form-group">
				    <label for="ven_name">Name</label>
				    <input type="text" name="name" class="form-control" id="ven_name" placeholder="Enter vendor name">
				</div>
				<div class="form-group">
				    <label for="ven_mob">Mobile Number</label>
				    <input type="number" name="phone" class="form-control" id="ven_mob" placeholder="Enter vendor mobile number">
				</div>
				<div class="form-group">
				    <label for="ven_email">Email_id</label>
				    <input type="email" name="email" class="form-control" id="ven_email" aria-describedby="emailHelp" placeholder="Enter vendor email">
				</div>
				<div class="form-group">
				    <label for="ven_address">Address</label>
				    <textarea class="form-control" name="address" id="ven_address" rows="3" placeholder="Enter vendor address"></textarea>
				</div>
				<div>
				  	<a href="vendor_list.php">View all the items</a>		
				</div>
				<div>
				  	<input style="margin-top: 10px" type="submit" name="submit" class="btn btn-success btn-block">
				</div>
			</form>

		</div>
	</div>
</div>


<?php 

if(isset($_POST['submit'])){

$con = mysql_connect("localhost","SMMS","smms");
if(!$con){
	die("Cannot Connect" . mysql_error());
}

mysql_select_db("supermarket",$con);

$sql = "INSERT INTO vendors (V_Name,Phone,Email,Address) values('$_POST[name]', $_POST[phone], '$_POST[email]', '$_POST[address]')";

if(mysql_query($sql, $con)){
	header('Location: vendor_list.php');
}else{
	echo "Error:" . mysql_error();
}

mysql_close($con);
}

?>

<?php require 'footer.php';
?>