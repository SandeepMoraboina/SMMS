<!DOCTYPE html>
<html>
<head>
	<title>Sql Connect</title>
</head>
<body>

<?php 
$con = mysql_connect("localhost","SMMS","smms");
if(!$con){
	die("Cannot Connect".mysql_error());
}

mysql_select_db("supermarket",$con);

$sql = "CREATE TABLE employees (
		e_id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
		e_name VARCHAR(30) NOT NULL ,
		e_age INT (2) NOT NULL ,
		e_phone BIGINT(10) NOT NULL UNIQUE,
		e_email VARCHAR(50) NOT NULL UNIQUE,
		e_address VARCHAR(100) NOT NULL,
		e_section INT(6) NOT NULL
		)";

if(mysql_query($sql, $con)){
	echo "Table Successfully created";
}else{
	echo "Error" . mysql_error();
}

mysql_close($con);
?>

</body>
</html>