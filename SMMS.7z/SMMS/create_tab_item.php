<!DOCTYPE html>
<html>
<head>
	<title>Sql Connect</title>
</head>
<body>

<?php 
$con = mysql_connect("localhost","SMMS","smms");
if(!$con){
	die("Cannot Connect".mysql_error());
}

mysql_select_db("supermarket",$con);

$sql = "CREATE TABLE items (
		id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
		name VARCHAR(30) NOT NULL,
		price INT(5) NOT NULL,
		remarks VARCHAR(100),
		vendor_id INT(6) NOT NULL,
		section_id INT(6) NOT NULL,
		entry_date TIMESTAMP
		)";

if(mysql_query($sql, $con)){
	echo "Table Successfully created";
}else{
	echo "Error" . mysql_error();
}

mysql_close($con);
?>

</body>
</html>