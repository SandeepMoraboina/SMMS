<?php require 'headerDB.php';
?>
<div class="container">
	<div class="row">
		<?php

		$name = null; 
		$phone = null;
		$email = null; 
		$place = null; 
		$Pid = null;

		$id = $_POST['vendor'];
		$iname = $_POST['name'];


		if(isset($_POST['deleteItem'])){
			$DelVen = "DELETE FROM items WHERE id='$_POST[hidden_id]'";
			if(mysql_query($DelVen, $con)){
				header('Location: item_list.php');
			} else{
				echo "Error:" . mysql_error();
			}
		}	


		$iselec = "SELECT * FROM items WHERE name ='$iname' AND vendor_id = $id";
		$myidata = mysql_query($iselec, $con);

		while($ifetch = mysql_fetch_array($myidata)){
			$Pid = $ifetch['id'];
			break;
		}

		echo "<div  style='width: 60%; margin: 30px auto;' class='jumbotron' id='jumbo-show'>
		<div>
		<h1> Product Name: " . $_POST['name'] . "</h1> 
		<h4> Id: " . $Pid . "</h4> 
		<h4> Present in Section: " . $_POST['section'] . "</h4>
		<h4> Price(in Rs): " . $_POST['price'] . "</h4>
		<h4> Remarks: " . $_POST['remarks'] . "</h4>
		<h4> Vendor-Id: " . $_POST['vendor'] . "</h4>
		</div>
		</div>"; 



		echo "<form action= 'item_update.php' method= 'POST' >" .
				"<input type=hidden name=hidden_id value=" .$Pid .">" .
				"<input type=hidden name=hidden_name value=" .$_POST['name'] .">" .
				"<input type=hidden name=hidden_price value=" .$_POST['price'] .">" .
				"<input type=hidden name=hidden_remarks value=" .$_POST['remarks'] .">" .
				"<input type=hidden name=hidden_vid value=" .$_POST['vendor'] .">" .
				"<input type=submit class='btn btn-success btn-lg' style='float: left; margin-left: 300px;' name=updateItem value=Update>" .
			"</form>";

		echo "<form action= 'item_show.php' method= 'POST' >" .
				"<input type=hidden name=hidden_id value=" .$Pid .">" .
				"<input type=submit class='btn btn-danger btn-lg' style='float: right; margin-right: 300px; margin-bottom:30px;' name=deleteItem value=Delete>" .
			"</form> <br /> <br /> ";



		$sql = "SELECT * FROM vendors WHERE v_id = $id";
		$mydata = mysql_query($sql, $con);

		if(mysql_affected_rows() != 0){

		while($vfetch = mysql_fetch_array($mydata)){
			$name = $vfetch['v_name'];
			$phone = $vfetch['phone'];
			$email = $vfetch['email']; 
			$place = $vfetch['address'];
			break;
		}

		echo "<hr style='margin-left:385px'>
		<div  style='width: 60%; margin: 30px auto;' class='jumbotron' id='jumbo-show'>
		<div>
		<h1> Sold By: " . $name . "</h1>
		<h4> Contact:" . $phone . "</h4>
		<h4> Email-Id:" . $email . "</h4> 
		<h4> Place:" . $place . "</h4>
		</div>
		</div>"; 



		echo "<form action='vendors_show.php' method='POST'>
				<input type=hidden name=name value=$name> 
				<input type=hidden name=phone value=$phone> 
				<input type=hidden name=email value=$email>
				<input type=hidden name=address value=$place> 
				<input  type=submit style='float: left; margin-left: 300px;' class='btn btn-primary btn-lg' name=more value='More Items'> <br />
			  </form>";

		}
		mysql_close($con);
		?>

	</div>
</div>


<?php require 'footer.php';
?>
