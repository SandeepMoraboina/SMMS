<?php require 'headerDB.php';

?>
<div class="container ccenter">
	<div class="jumbotron">
		<h1>All the Sections in the Supermarket</h1>
		<a class="btn btn-primary btn-lg btn-list" href="add_section.php">Add new Section</a>
	</div>

<?php
 
$sql = "SELECT * FROM sections";
$myData = mysql_query($sql, $con);

if(mysql_affected_rows() != 0){
echo "<div class='container'>
	<table class='tabsec' border=1>
	<tr>
		<th>Section ID</th>
		<th>Name</th>
		<th>Show</th>
	</tr>";

while($require = mysql_fetch_array($myData)){
	echo "<form action = 'section_show.php' method='POST'>";
	echo "<tr>";
	echo "<td>" . "<input class='ilist' type=number readonly name=id value=" .$require['s_id'] .">" . "</td>";
	echo "<td>" . "<input class='ilist' type=text readonly name=name value=" .$require['s_name'] .">" . "</td>"; 
	echo "<td>" . "<input class='btn btn-success btn-show' type=submit readonly name=show value= Show>" . "</td>"; 
	echo "<td>" . "<textarea class='ilist' style='display: none;' readonly name=description>" .$require['description'] ."</textarea>" . "</td>"; 
	echo "</tr>";
	echo "</form>";
}
echo "</table>
		</div>";
}else{
	echo "<div class='alert alert-danger'>
			  <strong>Note!</strong> No sections to display.
			</div>";
}

mysql_close($con);

?>

<?php require 'footer.php';
?>	
</div>
