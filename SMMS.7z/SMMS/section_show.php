<?php require 'headerDB.php';
?>
<div class="container">
	<div class="row">
		<?php
			$value = null;
			$price = null;
			$remarks = null;
			$vendor = null;
			$section = null;

			echo "<div class='jumbotron' id='jumbo-sec'>
			<h1>" . $_POST['name'] . " Section" . "</h1>
			<h4> Section No: " . $_POST['id'] . "</h4>
			<h4> Description: " . $_POST['description'] . "</h4>
			</div>"; 

			echo "<form action= 'section_update.php' method= 'POST' >" .
					"<input type=hidden name=hidden_name value=" .$_POST['name'] .">" .
					"<input type=hidden name=hidden_id value=" .$_POST['id'] .">" .
					"<input class='btn btn-primary btn-lg' type=submit name=updateSection value=Update>" .
				"</form> <br />";

			$Sid = $_POST['id'];


			$sql = "SELECT * FROM items WHERE section_id ='$Sid'";
			$mydata = mysql_query($sql, $con);

			if(isset($_POST['deleteSection'])){
					$DelSec = "DELETE FROM sections WHERE s_id='$_POST[hidden_id]'";
					if(mysql_query($DelSec, $con)){
							header('Location: section_list.php');
					} else{
							echo "Error:" . mysql_error();
					}
			}


			if(mysql_affected_rows() != 0){
			echo "<div class='ccenter container'>
			<h3>Items in this section</h3>
			<table border=1 style='margin-left:70px;'>
			<tr>
				<th>Product_id</th>
				<th>Name</th>
				<th>Price</th>
				<th>Remarks</th>
				<th>Vendor_id</th>
				<th>Show</th>
			</tr>";

			while($require = mysql_fetch_array($mydata)){
				echo "<form action = 'item_show.php' method='POST'>";
				echo "<tr>";
				echo "<td>" . "<input class='ilist' type=number readonly name=id value=" .$require['id'] .">" . "</td>";
				echo "<td>" . "<input class='ilist' type=text readonly name=name value=" .$require['name'] .">" . "</td>"; 
				echo "<td>" . "<input class='ilist' type=number readonly name=price value=" .$require['price'] .">" . "</td>"; 
				echo "<td>" . "<input class='ilist' type=text readonly name=remarks value=" .$require['remarks'] .">" . "</td>";  
				echo "<td>" . "<input class='ilist' type=number readonly name=vendor value=" .$require['vendor_id'] .">" . "</td>";
				echo "<td>" . "<input type=submit class='btn btn-success btn-show' readonly name=show value= Show>" . "</td>"; 
				echo "<td>" . "<input type=hidden readonly name=section value=" .$require['section_id'] .">" . "</td>"; 
				echo "</tr>";
				echo "</form>";
				echo "</tr>"; 
			}

			echo "</table>
			</div>";
			
			}else{
				echo "<form action= 'section_show.php' method= 'POST' >" .
						"<input type=hidden name=hidden_id value=" . $_POST['id'] .">" .
						"<input class='btn btn-danger btn-lg' type=submit name=deleteSection value=Delete>" .
					 "</form> <br />";

					 echo "<div class='alert alert-danger'>
						  <strong>Note!</strong> This Section has no items.
						</div>";
			}



			$esql = "SELECT * FROM employees WHERE e_section ='$Sid'";
			$emydata = mysql_query($esql, $con);
			
			if(mysql_affected_rows() != 0){
				echo "<hr>";
			echo "<div class='ccenter container'>
			<h3>Employees in this Section</h3>
			<table border=1>
			<tr>
				<th>Employee-ID</th>
				<th>Name</th>
				<th>Age</th>
				<th>Phone No.</th>
				<th>Email-ID</th>
				<th>Section</th>
				<th>Show</th>
			</tr>";	

			while($erequire = mysql_fetch_array($emydata)){
				echo "<form action = 'employee_show.php' method='POST'>";
				echo "<tr>";
				echo "<td>" . "<input class='ilist' type=number name=id readonly value=" .$erequire['e_id'] .">" . "</td>"; 
				echo "<td>" . "<input class='ilist' type=text name=name readonly value=" .$erequire['e_name'] .">" . "</td>";
				echo "<td>" . "<input class='ilist' type=number name=age readonly value=" .$erequire['e_age'] .">" . "</td>"; 
				echo "<td>" . "<input class='ilist' type=number name=phone readonly value=" .$erequire['e_phone'] .">" . "</td>"; 
				echo "<td>" . "<input class='ilist' type=text name=email readonly value=" .$erequire['e_email'] .">" . "</td>";
				echo "<td>" . "<input class='ilist' type=number name=section readonly value=" .$erequire['e_section'] .">" . "</td>";    
				echo "<td>" . "<input type=submit class='btn btn-success btn-show' name=show value= Show>" . "</td>"; 
				echo "<td>" . "<textarea style='display: none;' readonly name=address>" .$erequire['e_address'] ."</textarea>" . "</td>";
				echo "</tr>";
				echo "</form>";
			}
			echo "</table>
			</div>";
		}else{
				echo "<div class='alert alert-danger'>
						  <strong>Note!</strong> This Section has no Employees.
						</div>";
			}

			mysql_close($con);

		?>
	</div>
</div>


<?php require 'footer.php';
?>
