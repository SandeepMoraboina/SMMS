<!DOCTYPE html>
<html lang="en">
<head>
	<title>SMMS</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="company.css">
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="jumbotron text-center">
	<h1>Super Market Management System</h1>
	<h2>(SMMS)</h2>
	<p>Your Super Market Simplified by Recommending Products.</p>
</div>

<div class="container-fluid">
	<div class="row">
		<div class="col-sm-8">
			<h2>Items</h2>
			<h4>Find all the items at the same place</h4>
			<p>Listing of all the items available in the shop from various sections. <br /> Dive in and grab what you are lookng for.</p>
			<a class="btn btn-lg btn-default" href="item_list.php">Shop Now</a>
		</div>
		<div class="col-sm-4">
			<span class="glyphicon glyphicon-sort-by-alphabet logo"></span>
		</div>
	</div>
</div>

<div class="container-fluid bg-grey">
	<div class="row">
		<div class="col-sm-4">
			<span class="glyphicon glyphicon-check logo"></span>
		</div>
		<div class="col-sm-8">
			<h2>Sections</h2>
			<h4>Shop by type</h4>
			<p>Looking for something of particular type ? <br /> Here you can select from the sections and find the items present <br /> in that particular class.</p>
			<a class="btn btn-lg btn-default" href="section_list.php">Shop Now</a>
		</div>
	</div>
</div>

<div class="container-fluid">
	<div class="row">
		<div class="col-sm-8">
			<h2>Vendors</h2>
			<h4>Shop by the supplier</h4>
			<p>Like stuff from a particular supplier only ? <br /> List of all the items present under a particular supplier. <br /> This simplified search can save you time if you are looking for a specific product <br /> from a specific vendor</p>
			<a class="btn btn-lg btn-default" href="vendor_list.php">Shop Now</a>
		</div>
		<div class="col-sm-4">
			<span class="glyphicon glyphicon-user logo"></span>
		</div>
	</div>
</div>

<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.js"></script>
</body>
</html>