<div style="margin-top: 10px;">
	<p>&#xA9; SMMS a product of Sandoo Pvt. Ltd.</p> 
</div>
	<script type="text/javascript" src="jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>